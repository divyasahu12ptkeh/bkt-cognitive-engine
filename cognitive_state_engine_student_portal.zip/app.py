import copy
import json
import math
import hashlib
import hmac
import secrets
import sqlite3
import calendar
from datetime import date, datetime, timedelta
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from engine import BKTParams, Concept, mastery_at, mastery_curve, time_to_threshold, update

DEFAULT_BANK = {
    "Binary Search": [
        ("Time complexity of binary search on a sorted array?", ["O(n)", "O(log n)", "O(n log n)", "O(1)"], 1),
        ("Binary search requires the array to be...", ["Sorted", "Unique", "Even-sized", "Linked"], 0),
        ("low=0, high=9: mid = (low+high)//2 equals?", ["3", "5", "4", "9"], 2),
        ("If target < arr[mid], search next in the...", ["Right half", "Left half", "Whole array", "Stop"], 1),
    ],
    "Stacks": [
        ("A stack follows which order?", ["FIFO", "LIFO", "Random", "Priority"], 1),
        ("Which structure manages function calls?", ["Queue", "Heap", "Stack", "Graph"], 2),
        ("Popping from an empty stack is called?", ["Overflow", "Underflow", "Deadlock", "Null"], 1),
        ("Best structure to check balanced parentheses?", ["Queue", "Stack", "Array only", "Tree"], 1),
    ],
    "Recursion": [
        ("Every recursive function needs a...", ["Loop", "Base case", "Global", "Pointer"], 1),
        ("No base case usually causes?", ["Stack overflow", "Faster code", "Underflow", "Nothing"], 0),
        ("fact(n)=n*fact(n-1), fact(0)=1. fact(5)?", ["25", "60", "120", "720"], 2),
        ("Naive recursive Fibonacci time complexity?", ["O(n)", "O(log n)", "O(n^2)", "O(2^n)"], 3),
    ],
}
PALETTE = ["#1e3a8a", "#0f766e", "#b45309", "#6d28d9", "#334155", "#9f1239"]
T_FORGET, T_REVIEW, P_INIT = 0.5, 0.7, 0.20
PROGRESS = Path(__file__).with_name("progress.json")   # saved between runs
QFILE = Path(__file__).with_name("questions.json")     # questions you add in the app
DEMO = [("Binary Search", [True, True, False, True, True]), ("Stacks", [True, False, True])]


def load_bank():
    bank = {k: list(v) for k, v in DEFAULT_BANK.items()}
    try:
        custom = json.loads(QFILE.read_text())
    except Exception:
        custom = {}
    for concept, items in custom.items():
        for it in items:
            bank.setdefault(concept, []).append((it["q"], it["options"], it["answer"]))
    return bank


def save_custom_question(concept, q, options, answer):
    try:
        data = json.loads(QFILE.read_text())
    except Exception:
        data = {}
    data.setdefault(concept, []).append({"q": q, "options": options, "answer": answer})
    QFILE.write_text(json.dumps(data, indent=2))


def answers_to_goal(c, t, p, goal=0.9, cap=15):
    """How many correct answers in a row (1 min apart) until mastery >= goal."""
    k, tt = copy.deepcopy(c), t
    for n in range(1, cap + 1):
        tt += 1
        update(k, True, tt, p)
        if k.p_known >= goal:
            return n
    return None


# ---------- saved stats (days visited, questions solved) ----------
def load_stats():
    try:
        d = json.loads(PROGRESS.read_text())
    except Exception:
        d = {}
    d.setdefault("visit_dates", [])
    d.setdefault("attempted", {})
    d.setdefault("correct", {})
    return d


def save_stats(d):
    try:
        PROGRESS.write_text(json.dumps(d, indent=2))
    except Exception:
        pass


def streak(dates):
    days, cur, n = {date.fromisoformat(x) for x in dates}, date.today(), 0
    while cur in days:
        n, cur = n + 1, cur - timedelta(days=1)
    return n


def fmt_dur(m):
    m = int(round(m))
    if m < 60:
        return f"{m} min"
    if m < 1440:
        return f"{m // 60} h {m % 60} min"
    return f"{m // 1440} d {(m % 1440) // 60} h"


st.set_page_config(page_title="Cognitive State Engine", layout="wide")
S = st.session_state

# ---------- Student accounts and activity analytics ----------
DATA_DIR = Path(__file__).with_name("student_data")
DATA_DIR.mkdir(exist_ok=True)
AUTH_DB = DATA_DIR / "accounts.sqlite3"

def db_connect():
    conn = sqlite3.connect(AUTH_DB)
    conn.execute("CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, salt TEXT NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL)")
    conn.execute("CREATE TABLE IF NOT EXISTS practice_events (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, concept TEXT NOT NULL, correct INTEGER NOT NULL, event_time TEXT NOT NULL)")
    conn.commit()
    return conn

def password_digest(password: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 250_000).hex()

def create_account(username: str, password: str):
    username = username.strip().lower()
    if not re.fullmatch(r"[a-z0-9_.-]{3,24}", username):
        return False, "Use 3–24 characters: letters, numbers, dot, underscore, or hyphen."
    if len(password) < 8:
        return False, "Password must be at least 8 characters."
    salt = secrets.token_bytes(16)
    try:
        with db_connect() as conn:
            conn.execute("INSERT INTO users(username,salt,password_hash,created_at) VALUES(?,?,?,?)",
                         (username, salt.hex(), password_digest(password, salt), datetime.now().isoformat(timespec="seconds")))
        return True, "Account created. You can now sign in."
    except sqlite3.IntegrityError:
        return False, "That username already exists. Choose another."

def verify_account(username: str, password: str) -> bool:
    with db_connect() as conn:
        row = conn.execute("SELECT salt,password_hash FROM users WHERE username=?", (username.strip().lower(),)).fetchone()
    if not row:
        return False
    return hmac.compare_digest(password_digest(password, bytes.fromhex(row[0])), row[1])

def record_practice(username: str, concept: str, correct: bool):
    with db_connect() as conn:
        conn.execute("INSERT INTO practice_events(username,concept,correct,event_time) VALUES(?,?,?,?)",
                     (username, concept, int(correct), datetime.now().isoformat(timespec="seconds")))

def load_activity(username: str, start: date, end: date):
    with db_connect() as conn:
        rows = conn.execute("SELECT event_time, correct FROM practice_events WHERE username=? AND event_time>=? AND event_time<? ORDER BY event_time",
                            (username, datetime.combine(start, datetime.min.time()).isoformat(),
                             datetime.combine(end + timedelta(days=1), datetime.min.time()).isoformat())).fetchall()
    return rows

if "student_username" not in S:
    st.markdown("<div style='max-width:760px;margin:4vh auto 0;'>", unsafe_allow_html=True)
    st.markdown("# Cognitive State Engine")
    st.caption("Student learning portal · Sign in to keep your practice history separate")
    login_tab, signup_tab = st.tabs(["Sign in", "Create student account"])
    with login_tab:
        with st.form("student_login"):
            login_user = st.text_input("Username", key="login_user")
            login_pass = st.text_input("Password", type="password", key="login_pass")
            login_submit = st.form_submit_button("Sign in", type="primary", width="stretch")
        if login_submit:
            if verify_account(login_user, login_pass):
                S.student_username = login_user.strip().lower()
                st.rerun()
            else:
                st.error("Username or password is incorrect.")
    with signup_tab:
        with st.form("student_signup"):
            new_user = st.text_input("Choose username", key="new_user", help="3–24 characters: letters, numbers, dot, underscore, hyphen")
            new_pass = st.text_input("Create password", type="password", key="new_pass", help="Use at least 8 characters")
            confirm_pass = st.text_input("Confirm password", type="password", key="confirm_pass")
            signup_submit = st.form_submit_button("Create account", type="primary", width="stretch")
        if signup_submit:
            if new_pass != confirm_pass:
                st.error("The passwords do not match.")
            else:
                ok, message = create_account(new_user, new_pass)
                (st.success if ok else st.error)(message)
    st.markdown("</div>", unsafe_allow_html=True)
    st.info("This is a local prototype. Accounts are stored on this computer; use a managed database and HTTPS before deploying publicly.")
    st.stop()

STUDENT = S.student_username
PROGRESS = DATA_DIR / f"progress_{hashlib.sha256(STUDENT.encode()).hexdigest()[:16]}.json"
with st.sidebar:
    st.markdown(f"**Signed in as** `{STUDENT}`")
    if st.button("Sign out", width="stretch"):
        del S["student_username"]
        for key in ["init", "t", "start", "msg", "flash", "bank", "concepts", "idx", "stats"]:
            S.pop(key, None)
        st.rerun()

st.markdown("""
<style>
:root { color-scheme: light; }
.stApp { font-family: Inter, "Segoe UI", -apple-system, BlinkMacSystemFont, Arial, sans-serif; background: #f5f7fb; color: #172033; }
[data-testid="stToolbar"], [data-testid="stDecoration"], footer { display: none !important; }
.block-container { padding-top: 1.6rem; padding-bottom: 3rem; max-width: 1440px; }
#MainMenu { visibility: hidden; }
h1, h2, h3, h4 { color: #111c35; letter-spacing: -0.025em; }
h2 { margin-top: .35rem; }
p, label, [data-testid="stMarkdownContainer"] { line-height: 1.55; }
[data-testid="stMetric"] { background: linear-gradient(145deg, #ffffff, #f8faff); border: 1px solid #e2e8f0; border-radius: 16px; padding: 17px 18px; box-shadow: 0 3px 12px rgba(20, 35, 70, .035); min-height: 108px; }
[data-testid="stMetricLabel"] p { color: #64748b; font-size: .72rem; text-transform: uppercase; letter-spacing: .075em; font-weight: 700; }
[data-testid="stMetricValue"] { color: #15274b; font-weight: 750; }
[data-testid="stMetricDelta"] { font-size: .78rem; }
.stTabs [data-baseweb="tab-list"] { gap: 6px; background: #e9eef7; border: 1px solid #e0e7f1; padding: 6px; border-radius: 14px; flex-wrap: wrap; }
.stTabs [data-baseweb="tab"] { border-radius: 10px; padding: 10px 15px; font-weight: 650; color: #53627c; background: transparent; }
.stTabs [aria-selected="true"] { background: #ffffff !important; color: #173b75 !important; box-shadow: 0 2px 7px rgba(25, 45, 80, .10); }
.stTabs [data-baseweb="tab-highlight"] { background: transparent; }
button[kind="primary"], [data-testid="stFormSubmitButton"] button { background: linear-gradient(135deg, #2457a7, #173b75); border: 1px solid #173b75; border-radius: 10px; color: #fff; font-weight: 650; transition: transform .15s ease, box-shadow .15s ease; }
button[kind="primary"]:hover, [data-testid="stFormSubmitButton"] button:hover { box-shadow: 0 5px 14px rgba(23, 59, 117, .22); transform: translateY(-1px); }
.stButton button, .stDownloadButton button { border-radius: 10px; font-weight: 600; }
[data-testid="stSidebar"] { background: #101d35; border-right: 1px solid #263854; }
[data-testid="stSidebar"] * { color: #e6edf8; }
[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p { color: #c1cee2; }
[data-testid="stSidebar"] hr { border-color: #34445f; }
[data-testid="stSidebar"] [data-testid="stSlider"] [data-baseweb="slider"] { padding-top: .4rem; }
[data-testid="stProgress"] > div { background: #e4eaf3; border-radius: 99px; height: 9px; }
[data-testid="stProgress"] > div > div { background: linear-gradient(90deg, #2f6bc1, #2aa89a); border-radius: 99px; }
[data-testid="stAlert"] { border-radius: 12px; }
[data-testid="stExpander"] { border: 1px solid #e1e7f0; border-radius: 12px; background: #fff; }
[data-testid="stDataFrame"], [data-testid="stTable"] { border: 1px solid #e1e7f0; border-radius: 12px; overflow: hidden; }
[data-testid="stRadio"] label, [data-testid="stCheckbox"] label { border-radius: 9px; }
[data-testid="stSelectbox"] [data-baseweb="select"] > div, [data-testid="stTextInput"] input { border-radius: 10px; }
div[data-testid="stVerticalBlockBorderWrapper"] { border-radius: 15px; border-color: #e1e7f0; background: rgba(255,255,255,.72); }
.chip { display: inline-block; padding: 4px 10px; border-radius: 999px; font-size: .72rem; font-weight: 700; letter-spacing: .01em; }
.chip-green { background: #dcfce7; color: #166534; }
.chip-amber { background: #fff0c2; color: #8a4b08; }
.chip-red { background: #ffe1e2; color: #a3202a; }
.chip-grey { background: #e8edf5; color: #52627a; }
.hero { position: relative; overflow: hidden; padding: 28px 30px 25px; border-radius: 20px; margin: 0 0 22px; color: white; background: radial-gradient(circle at 90% 10%, rgba(64, 157, 202, .38), transparent 28%), linear-gradient(120deg, #102343 0%, #173e75 58%, #176c78 100%); box-shadow: 0 12px 28px rgba(19, 48, 87, .14); }
.hero-kicker { color: #a9d5f0; font-size: .72rem; font-weight: 750; letter-spacing: .16em; text-transform: uppercase; margin-bottom: 8px; }
.hero-title { color: #fff; font-size: clamp(1.7rem, 3vw, 2.35rem); line-height: 1.15; font-weight: 800; letter-spacing: -.04em; margin-bottom: 8px; }
.hero-subtitle { color: #d6e4f5; font-size: .96rem; max-width: 760px; }
.hero-tag { display: inline-block; margin-top: 17px; padding: 5px 10px; border: 1px solid rgba(255,255,255,.25); border-radius: 999px; color: #e9f4ff; background: rgba(255,255,255,.09); font-size: .72rem; }
.section-note { color: #66758d; font-size: .9rem; margin-top: -.3rem; margin-bottom: 1rem; }
@media (max-width: 760px) { .block-container { padding: 1rem .8rem 2rem; } .hero { padding: 22px 20px; } .stTabs [data-baseweb="tab-list"] { gap: 3px; } .stTabs [data-baseweb="tab"] { padding: 8px 10px; font-size: .83rem; } }
</style>
""", unsafe_allow_html=True)

# ---------- sidebar: model parameters ----------
with st.sidebar:
    st.subheader("Model parameters")
    st.caption("Adjust a value and every calculation and curve updates immediately.")
    p_slip = st.slider("Slip probability (knows it, answers wrong)", 0.01, 0.40, 0.10, 0.01)
    p_guess = st.slider("Guess probability (does not know, answers right)", 0.01, 0.50, 0.25, 0.01)
    p_transit = st.slider("Learning rate per attempt", 0.01, 0.50, 0.15, 0.01)
    gain = st.slider("Memory strength multiplier, correct answer", 1.0, 3.0, 1.8, 0.1)
    loss = st.slider("Memory strength multiplier, wrong answer", 0.3, 1.0, 0.7, 0.05)
    P = BKTParams(P_INIT, p_transit, p_slip, p_guess, gain, loss)
    st.divider()
    st.subheader("Session")
    demo = st.button("Load sample scenario", width="stretch",
                     help="Fills the charts with simulated answers. Not counted in your statistics.")
    restart = st.button("Restart session", width="stretch", help="Keeps saved statistics.")
    wipe = st.button("Reset saved statistics", width="stretch")

if restart:
    for k in list(S.keys()):
        del S[k]
    st.rerun()

if "init" not in S:
    bank = load_bank()
    S.update(init=True, t=0.0, start=datetime.now(), msg=None, flash=None, bank=bank,
             concepts={n: Concept(n, P_INIT) for n in bank}, idx={n: 0 for n in bank},
             stats=load_stats())
    today = date.today().isoformat()
    if today not in S.stats["visit_dates"]:
        S.stats["visit_dates"].append(today)
        save_stats(S.stats)
if wipe:
    S.stats = {"visit_dates": [date.today().isoformat()], "attempted": {}, "correct": {}}
    save_stats(S.stats)
if demo:
    for n, seq in DEMO:
        if n in S.concepts:
            for ok in seq:
                S.t += 1
                update(S.concepts[n], ok, S.t, P)
            S.t += 45
    S.msg = None
    st.rerun()

dtm = lambda m: S.start + timedelta(minutes=m)
clock = lambda m: dtm(m).strftime("%d %b, %I:%M %p")
color = lambda n: PALETTE[list(S.bank).index(n) % len(PALETTE)]
chip = lambda text, tone: f"<span class='chip chip-{tone}'>{text}</span>"


def status(mv):
    if mv >= T_REVIEW:
        return "Strong", "green"
    if mv >= T_FORGET:
        return "Fading", "amber"
    return "Below threshold", "red"


# ---------- header + summary cards ----------
st.markdown("""
<div class="hero">
  <div class="hero-kicker">Adaptive learning analytics · PS 9</div>
  <div class="hero-title">Cognitive State Engine</div>
  <div class="hero-subtitle">Understand what you know, identify what needs attention, and plan your next revision with explainable learning analytics.</div>
  <span class="hero-tag">Bayesian Knowledge Tracing</span>
  <span class="hero-tag">Memory & retention modelling</span>
  <span class="hero-tag">Personalized practice</span>
</div>
""", unsafe_allow_html=True)

att, cor = sum(S.stats["attempted"].values()), sum(S.stats["correct"].values())
mastered = sum(mastery_at(k, S.t) >= T_REVIEW for k in S.concepts.values())
days, strk = len(set(S.stats["visit_dates"])), streak(S.stats["visit_dates"])
c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Days active", days, delta=f"Current streak: {strk} day(s)", delta_color="off")
c2.metric("Questions solved", cor, delta=f"{att} attempted", delta_color="off")
c3.metric("Accuracy", f"{cor / att:.0%}" if att else "n/a")
c4.metric("Concepts mastered", f"{mastered} of {len(S.bank)}", delta="Mastery of 70% or more", delta_color="off")
c5.metric("Session clock", dtm(S.t).strftime("%I:%M %p"), delta=dtm(S.t).strftime("%d %b %Y"), delta_color="off")
st.write("")

tab_practice, tab_recovery, tab_plan, tab_curves, tab_math, tab_progress, tab_advanced, tab_add = st.tabs(
    ["Practice", "Recovery", "Study Plan", "Memory Curves", "Model Method", "Progress", "Exam Readiness", "Question Bank"])

# ---------- Practice ----------
with tab_practice:
    left, right = st.columns([1.2, 1], gap="large")
    with left:
        mode = st.radio("Mode", ["Select a concept", "Adaptive (weakest concept first)"], horizontal=True)
        if mode.startswith("Adaptive"):
            name = min(S.bank, key=lambda n: mastery_at(S.concepts[n], S.t))
            st.info(f"Adaptive mode selected **{name}**, where current mastery is lowest "
                    f"({mastery_at(S.concepts[name], S.t):.0%}).")
        else:
            name = st.selectbox("Concept", list(S.bank))
        c = S.concepts[name]
        q, opts, ans = S.bank[name][S.idx[name] % len(S.bank[name])]
        st.markdown(f"**Question {S.stats['attempted'].get(name, 0) + 1}.** {q}")
        choice = st.radio("Options", opts, index=None, key=f"{name}-{S.idx[name]}",
                          label_visibility="collapsed")
        if st.button("Submit answer", type="primary", disabled=choice is None):
            ok = opts.index(choice) == ans
            S.t += 1
            before = mastery_at(c, S.t)
            update(c, ok, S.t, P)
            S.idx[name] += 1
            S.stats["attempted"][name] = S.stats["attempted"].get(name, 0) + 1
            if ok:
                S.stats["correct"][name] = S.stats["correct"].get(name, 0) + 1
            save_stats(S.stats)
            record_practice(STUDENT, name, ok)
            S.msg = dict(ok=ok, name=name, ans=opts[ans], before=before, after=c.p_known)
            st.rerun()
        m = S.msg
        if m:
            text = f"{m['name']}: mastery changed from {m['before']:.0%} to {m['after']:.0%}."
            (st.success if m["ok"] else st.error)(
                ("Correct. " if m["ok"] else f"Incorrect. The right answer is {m['ans']}. ") + text)
        st.markdown("**Advance simulated time**")
        st.caption("Moves the session clock forward so memory decay can be observed without waiting.")
        b1, b2, b3 = st.columns(3)
        for col, label, mins in ((b1, "+30 minutes", 30), (b2, "+6 hours", 360), (b3, "+1 day", 1440)):
            if col.button(label, width="stretch"):
                S.t += mins
                S.msg = None
                st.rerun()
    with right:
        st.markdown("**Current mastery by concept**")
        for n, k in S.concepts.items():
            mv = mastery_at(k, S.t)
            label, tone = status(mv)
            st.markdown(f"**{n}** &nbsp; {chip(label, tone)} &nbsp; {mv:.0%}", unsafe_allow_html=True)
            st.progress(min(max(mv, 0.0), 1.0))
        st.caption("Strong: 70% and above. Fading: 50% to 70%. Below threshold: under 50%.")


# ---------- Learning Recovery Mode ----------
with tab_recovery:
    st.markdown("### Learning Recovery Mode")
    st.caption(
        "A focused loop that identifies a topic to revisit, gives targeted practice, "
        "and updates the same mastery and memory model used by the main Practice tab."
    )

    recovery_mastery = {
        n: mastery_at(k, S.t) for n, k in S.concepts.items()
    }
    weakest_default = min(recovery_mastery, key=recovery_mastery.get)
    recovery_concept = st.selectbox(
        "Choose a concept to recover",
        list(S.bank),
        index=list(S.bank).index(weakest_default),
        key="recovery_concept",
    )
    rc = S.concepts[recovery_concept]
    rm = mastery_at(rc, S.t)
    attempted_for_topic = S.stats["attempted"].get(recovery_concept, 0)
    correct_for_topic = S.stats["correct"].get(recovery_concept, 0)
    topic_accuracy = correct_for_topic / attempted_for_topic if attempted_for_topic else None

    metric1, metric2, metric3 = st.columns(3)
    metric1.metric("Estimated mastery", f"{rm:.0%}")
    metric2.metric("Questions attempted", attempted_for_topic)
    metric3.metric("Historical accuracy", f"{topic_accuracy:.0%}" if topic_accuracy is not None else "Not enough data")

    if rm < T_FORGET:
        st.error("Priority: rebuild the basics. The model estimates this concept is below 50% mastery.")
    elif rm < T_REVIEW:
        st.warning("Priority: practice and review. The model estimates this concept is fading.")
    else:
        st.success("This concept is currently in the strong range. Use recovery practice to keep it there.")

    recovery_guidance = {
        "Binary Search": [
            "Check the prerequisite: the input array must be sorted.",
            "Identify low, high, and the midpoint before choosing a half.",
            "If the target is smaller than the midpoint value, continue in the left half.",
        ],
        "Stacks": [
            "Remember LIFO: the last item pushed is the first item popped.",
            "Trace each push and pop in order.",
            "For nested or balanced parentheses, use a stack to track the most recent opening bracket.",
        ],
        "Recursion": [
            "Find the base case first; it stops the recursive calls.",
            "Write the smaller subproblem, such as fact(n - 1).",
            "For time complexity, count how many recursive calls are made and how the input size changes.",
        ],
    }
    st.markdown("#### Recovery steps")
    steps = recovery_guidance.get(
        recovery_concept,
        [
            "Review the definition and prerequisites for this concept.",
            "Solve one question slowly and explain why each option is right or wrong.",
            "Try another question without looking at the previous answer.",
        ],
    )
    for step_no, step in enumerate(steps, 1):
        st.markdown(f"{step_no}. {step}")

    st.markdown("#### Targeted practice")
    recovery_idx = S.setdefault("recovery_idx", {})
    recovery_idx.setdefault(recovery_concept, 0)
    rq, ropts, rans = S.bank[recovery_concept][recovery_idx[recovery_concept] % len(S.bank[recovery_concept])]
    st.markdown(f"**Question:** {rq}")
    recovery_choice = st.radio(
        "Choose your answer",
        ropts,
        index=None,
        key=f"recovery_answer_{recovery_concept}_{recovery_idx[recovery_concept]}",
        label_visibility="collapsed",
    )

    if st.button("Check recovery answer", type="primary", disabled=recovery_choice is None,
                 key=f"recovery_submit_{recovery_concept}_{recovery_idx[recovery_concept]}"):
        recovery_ok = ropts.index(recovery_choice) == rans
        S.t += 1
        update(rc, recovery_ok, S.t, P)
        S.stats["attempted"][recovery_concept] = S.stats["attempted"].get(recovery_concept, 0) + 1
        if recovery_ok:
            S.stats["correct"][recovery_concept] = S.stats["correct"].get(recovery_concept, 0) + 1
        save_stats(S.stats)
        S["recovery_feedback"] = {
            "concept": recovery_concept,
            "question": rq,
            "correct": recovery_ok,
            "answer": ropts[rans],
            "mastery": mastery_at(rc, S.t),
        }
        S["recovery_idx"][recovery_concept] += 1
        st.rerun()

    feedback = S.get("recovery_feedback")
    if feedback and feedback["concept"] == recovery_concept:
        if feedback["correct"]:
            st.success(
                f"Correct! The answer is **{feedback['answer']}**. "
                f"Your updated estimated mastery is {feedback['mastery']:.0%}."
            )
        else:
            st.error(
                f"Not quite. The correct answer is **{feedback['answer']}**. "
                f"Your updated estimated mastery is {feedback['mastery']:.0%}."
            )

        explanations = {
            "Binary Search": {
                "Time complexity of binary search on a sorted array?": "Binary search halves the remaining search interval each step, so its time complexity is O(log n).",
                "Binary search requires the array to be...": "Binary search relies on sorted order to safely discard half of the remaining elements.",
                "low=0, high=9: mid = (low+high)//2 equals?": "The midpoint is (0 + 9) // 2 = 4 using integer division.",
                "If target < arr[mid], search next in the...": "When the target is smaller than the middle element in an ascending sorted array, search the left half.",
            },
            "Stacks": {
                "A stack follows which order?": "A stack follows Last In, First Out (LIFO).",
                "Which structure manages function calls?": "Function calls and return addresses are commonly managed using the call stack.",
                "Popping from an empty stack is called?": "Trying to remove an item from an empty stack is called underflow.",
                "Best structure to check balanced parentheses?": "A stack tracks opening parentheses and matches them as closing parentheses appear.",
            },
            "Recursion": {
                "Every recursive function needs a...": "A base case tells recursion when to stop.",
                "No base case usually causes?": "Without a reachable stopping condition, recursive calls can continue until a stack overflow occurs.",
                "fact(n)=n*fact(n-1), fact(0)=1. fact(5)?": "5! = 5 × 4 × 3 × 2 × 1 = 120.",
                "Naive recursive Fibonacci time complexity?": "The naive recursive Fibonacci implementation repeats many subproblems, giving exponential time O(2^n) as a common upper-bound description.",
            },
        }
        explanation = explanations.get(recovery_concept, {}).get(feedback["question"])
        if explanation:
            st.info(f"**Why?** {explanation}")

    st.caption(
        "Note: mastery is a model estimate, not a diagnosis of ability. "
        "Recovery practice updates the same in-session concept state and saved question statistics."
    )


# ---------- Study plan ----------
with tab_plan:
    st.markdown("### Recommended revision order")
    plan = [(mastery_at(k, S.t), n, k, time_to_threshold(k, T_REVIEW), answers_to_goal(k, S.t, P))
            for n, k in S.concepts.items()]
    plan.sort(key=lambda x: x[0])
    if plan[0][0] < T_REVIEW:
        st.success(f"Start with **{plan[0][1]}**. Current mastery is {plan[0][0]:.0%}.")
    else:
        nxt = min(plan, key=lambda x: x[3])
        st.success(f"All concepts are at 70% or above. Next review: **{nxt[1]}**, before {clock(nxt[3])}.")
    st.caption("Concepts are ranked by current mastery, the model's estimate of what is remembered right now.")
    for rank, (mv, n, k, tr, need) in enumerate(plan, 1):
        with st.container(border=True):
            a, b, c_ = st.columns([1.2, 2, 1.6])
            a.markdown(f"**{rank}. {n}**")
            a.caption(f"Memory strength: {fmt_dur(k.stability)}")
            b.progress(min(max(mv, 0.0), 1.0), text=f"Current mastery: {mv:.0%}")
            if tr is None or tr <= S.t:
                b.markdown(chip("Revise now", "red"), unsafe_allow_html=True)
            else:
                b.markdown(f"{chip('Scheduled', 'amber')} &nbsp; Revise before {clock(tr)}", unsafe_allow_html=True)
            c_.metric("Correct answers to reach 90%", f"{need}" if need else "More than 15")
    st.caption("Select Adaptive mode in the Practice tab to follow this order automatically.")

# ---------- Memory curves ----------
with tab_curves:
    a, b = st.columns([3, 1])
    chosen = a.multiselect("Concepts", list(S.bank), default=list(S.bank))
    window = b.selectbox("Time window", ["Next 6 hours", "Next 24 hours", "Next 3 days", "Next 7 days"], index=1)
    span = {"Next 6 hours": 360, "Next 24 hours": 1440, "Next 3 days": 4320, "Next 7 days": 10080}[window]
    x0, x1 = max(S.t - 0.2 * span, 0), S.t + span

    fig = go.Figure()
    fig.add_hrect(y0=0, y1=50, fillcolor="#ef4444", opacity=0.06, line_width=0)
    fig.add_hrect(y0=70, y1=100, fillcolor="#22c55e", opacity=0.06, line_width=0)
    for y, txt in ((25, "Below threshold (under 50%)"), (85, "Strong (70% and above)")):
        fig.add_annotation(xref="paper", x=0.995, y=y, text=txt, showarrow=False,
                           xanchor="right", font=dict(size=11, color="#64748b"))
    for n in chosen:
        k, col = S.concepts[n], color(n)
        xs, ys = mastery_curve(k, x1)
        fig.add_trace(go.Scatter(
            x=[dtm(x) for x in xs], y=[v * 100 for v in ys], mode="lines", name=n,
            line=dict(color=col, width=2.5),
            hovertemplate=f"<b>{n}</b><br>%{{x|%d %b, %I:%M %p}}<br>Mastery: %{{y:.0f}}%<extra></extra>"))
        ev = k.history[1:]
        if ev:
            fig.add_trace(go.Scatter(
                x=[dtm(e[0]) for e in ev], y=[e[1] * 100 for e in ev], mode="markers", showlegend=False,
                marker=dict(size=10, color=col, line=dict(color="white", width=1.5),
                            symbol=["circle" if e[2] == "correct" else "x" for e in ev]),
                text=[f"Answered {e[2]}" for e in ev],
                hovertemplate=f"<b>{n}</b><br>%{{text}}<br>Mastery after: %{{y:.0f}}%<extra></extra>"))
        tf = time_to_threshold(k, T_FORGET)
        if tf and x0 <= tf <= x1:
            fig.add_trace(go.Scatter(
                x=[dtm(tf)], y=[50], mode="markers", showlegend=False,
                marker=dict(size=13, color=col, symbol="diamond", line=dict(color="white", width=2)),
                hovertemplate=f"<b>{n}</b><br>Mastery falls to 50% at {clock(tf)}<extra></extra>"))
    fig.add_shape(type="line", x0=dtm(S.t), x1=dtm(S.t), y0=0, y1=100,
                  line=dict(color="#475569", width=1.5, dash="dot"))
    fig.add_annotation(x=dtm(S.t), y=104, text="Current time", showarrow=False, font=dict(size=11, color="#475569"))
    fig.update_layout(
        template="plotly_white", height=460, margin=dict(l=10, r=10, t=30, b=10), hovermode="closest",
        legend=dict(orientation="h", y=1.08, x=0),
        xaxis=dict(range=[dtm(x0), dtm(x1)], nticks=6, tickformat="%I:%M %p<br>%d %b", showgrid=False),
        yaxis=dict(range=[0, 108], tickvals=[0, 25, 50, 75, 100], ticksuffix="%",
                   title="Estimated retention", gridcolor="rgba(148,163,184,0.25)"))
    st.plotly_chart(fig, width="stretch")
    st.caption("Circles mark correct answers, crosses mark incorrect answers, and diamonds mark the predicted "
               "point at which mastery falls to 50%. Hover over any point for exact values.")

    bar_col, tbl_col = st.columns([1, 1.6], gap="large")
    with bar_col:
        names = list(S.concepts)
        vals = [mastery_at(S.concepts[n], S.t) * 100 for n in names]
        bar = go.Figure(go.Bar(
            x=vals, y=names, orientation="h", text=[f"{v:.0f}%" for v in vals], textposition="outside",
            marker_color=["#15803d" if v >= 70 else "#b45309" if v >= 50 else "#b91c1c" for v in vals]))
        bar.update_layout(template="plotly_white", height=230, margin=dict(l=10, r=30, t=40, b=10),
                          title=dict(text="Mastery right now", font=dict(size=14)),
                          xaxis=dict(range=[0, 115], ticksuffix="%", showgrid=False))
        st.plotly_chart(bar, width="stretch")
    with tbl_col:
        rows = []
        for n, k in S.concepts.items():
            tr, tf = time_to_threshold(k, T_REVIEW), time_to_threshold(k, T_FORGET)
            rows.append({
                "Concept": n, "Memory strength": fmt_dur(k.stability),
                "Revise before": "Revise now" if tr is None or tr <= S.t else clock(tr),
                "Mastery falls to 50%": "Not learned yet" if tf is None else
                                        "Already below 50%" if tf <= S.t else clock(tf)})
        st.markdown("**Revision schedule**")
        st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")

# ---------- Method ----------
with tab_math:
    sel = st.selectbox("Concept", list(S.bank), key="math_concept")
    tr = S.concepts[sel].last_trace
    if not tr:
        st.info("Answer a question for this concept first. The exact calculation for the last answer appears here.")
    else:
        st.markdown(f"Calculation for the last answer ({'correct' if tr['correct'] else 'incorrect'}).")
        st.markdown(f"**Step 1. Forgetting before the answer.** {tr['dt']:.0f} minutes passed since the last practice.")
        st.latex(r"R = e^{-\Delta t / S} = e^{-" + f"{tr['dt']:.0f}/{tr['S_old']:.0f}" + r"} = " + f"{tr['R']:.3f}")
        st.latex(r"P(L)_{prior} = P(L) \times R = " + f"{tr['p_before']:.3f} \\times {tr['R']:.3f} = {tr['prior']:.3f}")
        if tr["correct"]:
            st.markdown("**Step 2. Bayesian update (correct answer).**")
            st.latex(r"P(L\,|\,correct) = \frac{P(L)(1-slip)}{P(L)(1-slip) + (1-P(L))\,guess}")
        else:
            st.markdown("**Step 2. Bayesian update (incorrect answer).**")
            st.latex(r"P(L\,|\,wrong) = \frac{P(L)\,slip}{P(L)\,slip + (1-P(L))(1-guess)}")
        st.latex(f"= \\frac{{{tr['num']:.3f}}}{{{tr['den']:.3f}}} = {tr['post']:.3f}")
        st.markdown("**Step 3. Learning from the attempt.**")
        st.latex(r"P(L)_{new} = post + (1-post)\times T = " +
                 f"{tr['post']:.3f} + {1 - tr['post']:.3f} \\times {tr['transit']:.2f} = {tr['p_new']:.3f}")
        mult = tr["gain"] if tr["correct"] else tr["loss"]
        st.markdown("**Step 4. Change in memory strength.**")
        st.latex(f"S_{{new}} = S \\times {mult:.2f} = {tr['S_old']:.0f} \\times {mult:.2f} = {tr['S_new']:.0f}\\ \\text{{min}}")
        st.markdown("**Step 5. Time until mastery falls to 50%.**")
        if tr["p_new"] > T_FORGET:
            tmin = tr["S_new"] * math.log(tr["p_new"] / T_FORGET)
            st.latex(r"t = S \ln\!\left(\frac{P(L)}{0.5}\right) = " +
                     f"{tr['S_new']:.0f} \\ln({tr['p_new']:.3f}/0.5) = {tmin:.0f}\\ \\text{{min}}")
            st.success(f"Predicted: mastery falls to 50% about {fmt_dur(tmin)} after this answer, at {clock(tr['t'] + tmin)}.")
        else:
            st.warning("Mastery is at or below 50%, so this concept is treated as not yet learned.")
    with st.expander("Model assumptions"):
        st.markdown(
            "- Bayesian Knowledge Tracing and the Ebbinghaus forgetting curve are established models.\n"
            "- The four BKT parameters are typical assumed values. A deployed system would estimate them from student data.\n"
            "- The memory strength multipliers (1.8 and 0.7) are a simple heuristic for the spacing effect.\n"
            "- Predicted forgetting times are model estimates and not guarantees for an individual student.")

# ---------- Progress ----------
with tab_progress:
    rows = []
    for n in S.bank:
        a_, c_ = S.stats["attempted"].get(n, 0), S.stats["correct"].get(n, 0)
        rows.append({"Concept": n, "Attempted": a_, "Solved": c_, "Accuracy": f"{c_ / a_:.0%}" if a_ else "n/a"})
    l, r = st.columns([1, 1.2], gap="large")
    with l:
        st.markdown("**Questions by concept**")
        st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")
        st.markdown("**Activity, last 7 days**")
        visited = set(S.stats["visit_dates"])
        for i, col in enumerate(st.columns(7)):
            d = date.today() - timedelta(days=6 - i)
            fill = "#1e3a8a" if d.isoformat() in visited else "#e2e8f0"
            col.markdown(
                f"<div style='text-align:center'><div style='width:32px;height:32px;margin:0 auto;"
                f"border-radius:6px;background:{fill}'></div>"
                f"<div style='font-size:0.72rem;color:#64748b;margin-top:4px'>{d:%a}</div></div>",
                unsafe_allow_html=True)
        st.caption(f"Saved in {PROGRESS.name}. Days active increases by one for each new day the app is opened.")
    with r:
        gb = go.Figure()
        gb.add_bar(name="Attempted", x=list(S.bank), y=[x["Attempted"] for x in rows], marker_color="#94a3b8")
        gb.add_bar(name="Solved", x=list(S.bank), y=[x["Solved"] for x in rows], marker_color="#1e3a8a")
        gb.update_layout(template="plotly_white", barmode="group", height=320, margin=dict(l=10, r=10, t=30, b=10),
                         legend=dict(orientation="h", y=1.1), yaxis=dict(dtick=1, rangemode="tozero"))
        st.plotly_chart(gb, width="stretch")

    st.markdown("**Milestones**")
    badges = [("First question solved", cor >= 1), ("10 questions solved", cor >= 10),
              ("3-day streak", strk >= 3), ("One concept mastered", mastered >= 1),
              ("All concepts mastered", mastered == len(S.bank))]
    for col, (label, got) in zip(st.columns(len(badges)), badges):
        col.markdown(f"<div style='text-align:center'>{chip('Earned', 'green') if got else chip('Locked', 'grey')}"
                     f"<div style='font-size:0.82rem;margin-top:6px'>{label}</div></div>", unsafe_allow_html=True)

    st.markdown("### Monthly practice heatmap")
    st.caption("Each cell represents one hour on one day. Darker colors mean more submitted practice answers in that hour.")
    month_choice = st.date_input("Choose a month", value=date.today().replace(day=1), key="activity_month")
    month_start = month_choice.replace(day=1)
    days_in_month = calendar.monthrange(month_start.year, month_start.month)[1]
    month_end = month_start + timedelta(days=days_in_month - 1)
    events = load_activity(STUDENT, month_start, month_end)
    grid = [[0 for _ in range(24)] for _ in range(days_in_month)]
    for event_time, _correct in events:
        try:
            dt = datetime.fromisoformat(event_time)
            if dt.year == month_start.year and dt.month == month_start.month:
                grid[dt.day - 1][dt.hour] += 1
        except ValueError:
            pass
    heat = go.Figure(data=go.Heatmap(
        z=grid,
        x=[f"{h:02d}:00" for h in range(24)],
        y=[f"{d:02d}" for d in range(1, days_in_month + 1)],
        colorscale=[[0, "#f1f5f9"], [0.25, "#bae6fd"], [0.5, "#38bdf8"], [0.75, "#0f766e"], [1, "#134e4a"]],
        zmin=0,
        colorbar=dict(title="Answers"),
        hovertemplate="Day %{y}, %{x}<br>Practice answers: %{z}<extra></extra>"))
    heat.update_layout(template="plotly_white", height=max(350, days_in_month * 13),
                       margin=dict(l=20, r=20, t=10, b=35),
                       xaxis=dict(title="Hour of day", tickangle=-45, side="bottom"),
                       yaxis=dict(title="Day of month", autorange="reversed"))
    st.plotly_chart(heat, width="stretch")
    st.markdown("**Color legend:** light = no/few answers · blue = moderate activity · dark teal = high activity.")
    st.caption(f"This chart counts submitted practice answers for the signed-in account. It does not count time spent reading or studying without submitting an answer. Total recorded answers this month: {sum(sum(row) for row in grid)}.")

    report = []
    for n, k in S.concepts.items():
        tr_, tf_ = time_to_threshold(k, T_REVIEW), time_to_threshold(k, T_FORGET)
        report.append({
            "Concept": n, "Attempted": S.stats["attempted"].get(n, 0), "Solved": S.stats["correct"].get(n, 0),
            "Mastery now (%)": round(mastery_at(k, S.t) * 100, 1),
            "Memory strength (min)": round(k.stability),
            "Revise before": "Revise now" if tr_ is None or tr_ <= S.t else clock(tr_),
            "Mastery falls to 50%": "Not learned yet" if tf_ is None else
                                    "Already below 50%" if tf_ <= S.t else clock(tf_)})
    st.write("")
    st.download_button("Download progress report (CSV)", pd.DataFrame(report).to_csv(index=False),
                       file_name="progress_report.csv", mime="text/csv")

# ---------- Exam readiness and explainable recommendations ----------
with tab_advanced:
    st.markdown("### Exam readiness dashboard")
    st.caption("A transparent revision aid based on the app's current mastery estimates and saved practice statistics. It is not a guaranteed exam score.")

    mastery_values = {n: mastery_at(k, S.t) for n, k in S.concepts.items()}
    total_attempts = sum(S.stats["attempted"].values())
    total_correct = sum(S.stats["correct"].values())
    overall_accuracy = total_correct / total_attempts if total_attempts else 0.0
    coverage = sum(S.stats["attempted"].get(n, 0) > 0 for n in S.bank) / max(1, len(S.bank))
    mean_mastery = sum(mastery_values.values()) / max(1, len(mastery_values))
    # Weighted readiness indicator: mastery 50%, practice accuracy 30%, topic coverage 20%.
    readiness = round(100 * (0.50 * mean_mastery + 0.30 * overall_accuracy + 0.20 * coverage))

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Readiness indicator", f"{readiness}/100")
    m2.metric("Mean estimated mastery", f"{mean_mastery:.0%}")
    m3.metric("Practice accuracy", f"{overall_accuracy:.0%}" if total_attempts else "No attempts yet")
    m4.metric("Topic coverage", f"{coverage:.0%}")
    st.progress(readiness / 100, text="Readiness indicator (weighted estimate)")
    st.info("Scoring method: 50% current mastery + 30% observed accuracy + 20% topic coverage. A topic counts as covered after at least one recorded attempt. Small samples can make this indicator unstable.")

    st.markdown("#### Topic risk register")
    risk_rows = []
    for n, k in S.concepts.items():
        mv = mastery_values[n]
        attempts_n = S.stats["attempted"].get(n, 0)
        correct_n = S.stats["correct"].get(n, 0)
        acc_n = correct_n / attempts_n if attempts_n else None
        if attempts_n == 0:
            risk, action = "Unassessed", "Attempt a diagnostic question"
        elif mv < 0.50 or (acc_n is not None and acc_n < 0.50):
            risk, action = "High", "Rebuild fundamentals, then retry"
        elif mv < 0.70 or (acc_n is not None and acc_n < 0.75):
            risk, action = "Moderate", "Complete targeted practice"
        else:
            risk, action = "Lower", "Schedule spaced revision"
        risk_rows.append({"Concept": n, "Estimated mastery": f"{mv:.0%}",
                          "Accuracy": f"{acc_n:.0%}" if acc_n is not None else "No data",
                          "Attempts": attempts_n, "Revision priority": risk, "Recommended action": action})
    risk_rows.sort(key=lambda row: {"High": 0, "Unassessed": 1, "Moderate": 2, "Lower": 3}[row["Revision priority"]])
    st.dataframe(pd.DataFrame(risk_rows), hide_index=True, width="stretch")

    st.markdown("#### Confidence calibration")
    st.caption("Rate your own confidence for each topic. Large gaps between confidence and model-estimated mastery can flag topics worth checking; confidence is subjective and does not change the learning model.")
    confidence = S.setdefault("confidence_rating", {})
    confidence_cols = st.columns(min(3, max(1, len(S.bank))))
    for i, n in enumerate(S.bank):
        with confidence_cols[i % len(confidence_cols)]:
            rating = st.slider(f"{n}: confidence", 0, 100, int(confidence.get(n, 50)), 5, key=f"confidence_{n}")
            confidence[n] = rating
            gap = rating / 100 - mastery_values[n]
            if gap >= 0.25:
                st.warning(f"Confidence is {gap:.0%} above estimated mastery. Verify with a few unaided questions.")
            elif gap <= -0.25:
                st.info("Your confidence is lower than the model estimate. Try a short self-test before deciding to relearn the topic.")
            else:
                st.caption("Confidence and estimated mastery are reasonably aligned.")

    st.markdown("#### Recommended next actions")
    prioritized = sorted(S.bank, key=lambda n: (mastery_values[n], S.stats["attempted"].get(n, 0)))
    for rank, n in enumerate(prioritized[:3], 1):
        mv = mastery_values[n]
        attempts_n = S.stats["attempted"].get(n, 0)
        if attempts_n == 0:
            suggestion = "Take a diagnostic question so the model has evidence."
        elif mv < T_FORGET:
            suggestion = "Review the core definition, study a worked example, then solve two targeted questions."
        elif mv < T_REVIEW:
            suggestion = "Do a short practice set and revisit this topic later today."
        else:
            suggestion = "Use spaced revision rather than spending the whole session here."
        st.markdown(f"**{rank}. {n} — {mv:.0%} estimated mastery**  \n{suggestion}")

    readiness_export = pd.DataFrame(risk_rows)
    st.download_button("Export exam-readiness report (CSV)", readiness_export.to_csv(index=False),
                        file_name="exam_readiness_report.csv", mime="text/csv")
    st.caption("Interpretation note: BKT mastery and forgetting-curve values are model estimates. Use this dashboard to guide revision, not as a prediction of an actual examination result.")


# ---------- Question bank ----------
with tab_add:
    st.markdown("### Add questions")
    st.caption("Questions are saved in questions.json next to app.py and remain after the app is restarted.")
    if S.flash:
        st.success(S.flash)
        S.flash = None
    with st.form("add_q", clear_on_submit=True):
        target = st.selectbox("Concept", list(S.bank) + ["New concept"])
        new_name = st.text_input("New concept name (only when 'New concept' is selected)")
        qtext = st.text_input("Question")
        o1, o2 = st.columns(2)
        options = [o1.text_input("Option 1"), o2.text_input("Option 2"),
                   o1.text_input("Option 3"), o2.text_input("Option 4")]
        correct_no = st.selectbox("Correct option", [1, 2, 3, 4])
        submitted = st.form_submit_button("Add question", type="primary")
    if submitted:
        concept = new_name.strip() if target == "New concept" else target
        opts = [x.strip() for x in options]
        if not concept or not qtext.strip() or not all(opts) or len(set(opts)) < 4:
            st.error("Enter the concept, the question, and four different options.")
        else:
            save_custom_question(concept, qtext.strip(), opts, correct_no - 1)
            S.bank.setdefault(concept, []).append((qtext.strip(), opts, correct_no - 1))
            if concept not in S.concepts:
                S.concepts[concept] = Concept(concept, P_INIT)
                S.idx[concept] = 0
            S.flash = f"Question added to {concept}. It now has {len(S.bank[concept])} questions."
            st.rerun()
    st.markdown("**Question bank summary**")
    st.dataframe(pd.DataFrame([{"Concept": n, "Questions": len(v)} for n, v in S.bank.items()]),
                 hide_index=True, width="stretch")
