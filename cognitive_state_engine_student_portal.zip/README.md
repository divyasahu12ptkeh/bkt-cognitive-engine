# Cognitive State Engine — Student Portal

## Features
- Student account creation and sign-in (SQLite, PBKDF2-HMAC password hashing)
- Per-account progress JSON files
- Hour-by-hour monthly practice heatmap
- Existing adaptive practice, mastery, memory curves, study plan, and question bank

## Run locally (Windows / VS Code)
1. Extract this folder and open it in VS Code.
2. In Terminal → New Terminal, run `python -m pip install -r requirements.txt`.
3. Run `python -m streamlit run app.py`.
4. Create an account on the sign-up tab, then sign in.

## Notes
- Account database and student data are stored in `student_data/` next to `app.py`. Keep this folder to preserve local accounts and practice history.
- This is a local classroom prototype, not production-ready authentication. Do not deploy publicly without HTTPS, stronger operational controls, backups, account recovery, and a managed database.
- The activity chart counts submitted answers by local computer time; it does not measure actual study duration.
